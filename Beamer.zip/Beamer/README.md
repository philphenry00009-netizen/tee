# Beamer

Video / URL -> clean, speaker-labeled script (Kotlin, Compose, Material 3).

Waterfall: captions (URL or embedded) -> ML Kit OCR with overlap stitching -> offline whisper.cpp + diarization.

## Build
- GitHub Actions: `.github/workflows/build-apk.yml` (clones whisper.cpp v1.7.4, installs NDK/CMake, builds the debug APK, publishes a release).
- Local: `git clone --depth 1 --branch v1.7.4 https://github.com/ggerganov/whisper.cpp app/src/main/cpp/whisper.cpp`, then open in Android Studio (NDK 26.1.10909125, CMake 3.22.1) and run.

## Notes
- Whisper model (tiny/base) downloads once on first audio use, then everything is offline.
- yt-dlp is bundled; sites change often, so URL extraction may need a newer youtubedl-android version over time.
- Diarization is a built-in lightweight clusterer (`Diarizer.kt`). Replace it with an ONNX speaker-embedding model for higher accuracy.
