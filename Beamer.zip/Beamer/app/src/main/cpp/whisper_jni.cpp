#include <jni.h>
#include <string>
#include "whisper.h"

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_beamer_WhisperNative_nativeInit(JNIEnv *env, jobject, jstring path) {
    const char *p = env->GetStringUTFChars(path, nullptr);
    struct whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    struct whisper_context *ctx = whisper_init_from_file_with_params(p, cparams);
    env->ReleaseStringUTFChars(path, p);
    return (jlong) ctx;
}

JNIEXPORT void JNICALL
Java_com_beamer_WhisperNative_nativeFree(JNIEnv *, jobject, jlong ptr) {
    if (ptr != 0) whisper_free((struct whisper_context *) ptr);
}

JNIEXPORT jbyteArray JNICALL
Java_com_beamer_WhisperNative_nativeTranscribe(JNIEnv *env, jobject, jlong ptr, jfloatArray audio,
                                               jint threads, jstring lang) {
    struct whisper_context *ctx = (struct whisper_context *) ptr;
    const char *l = env->GetStringUTFChars(lang, nullptr);
    std::string language(l);
    env->ReleaseStringUTFChars(lang, l);

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.print_special = false;
    params.translate = false;
    params.language = language.c_str();
    params.n_threads = threads;
    params.offset_ms = 0;
    params.no_context = true;
    params.single_segment = false;

    jfloat *data = env->GetFloatArrayElements(audio, nullptr);
    jsize n = env->GetArrayLength(audio);
    int rc = whisper_full(ctx, params, data, n);
    env->ReleaseFloatArrayElements(audio, data, JNI_ABORT);

    std::string out;
    if (rc == 0) {
        int ns = whisper_full_n_segments(ctx);
        for (int i = 0; i < ns; i++) {
            const char *t = whisper_full_get_segment_text(ctx, i);
            std::string txt = t ? t : "";
            for (auto &c : txt) { if (c == '\n' || c == '\t' || c == '\r') c = ' '; }
            out += std::to_string(whisper_full_get_segment_t0(ctx, i)) + "\t" +
                   std::to_string(whisper_full_get_segment_t1(ctx, i)) + "\t" + txt + "\n";
        }
    }
    jbyteArray arr = env->NewByteArray((jsize) out.size());
    env->SetByteArrayRegion(arr, 0, (jsize) out.size(), (const jbyte *) out.data());
    return arr;
}

}
