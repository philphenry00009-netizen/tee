package com.beamer

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

class ShortSink {
    private var data = ShortArray(1 shl 20)
    private var size = 0
    fun add(v: Short) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }
    fun toArray(): ShortArray = data.copyOf(size)
}

/** Streaming linear resampler to 16 kHz. */
class Resampler(var srcRate: Int, private val dstRate: Int) {
    private var phase = 0.0
    private var last = 0

    fun feed(x: ShortArray, n: Int, out: ShortSink) {
        if (n == 0) return
        val step = srcRate.toDouble() / dstRate
        while (phase < n - 1) {
            val i0 = Math.floor(phase).toInt()
            val frac = phase - i0
            val s0 = if (i0 < 0) last else x[i0].toInt()
            val s1 = x[i0 + 1].toInt()
            out.add((s0 + (s1 - s0) * frac).toInt().toShort())
            phase += step
        }
        phase -= n
        last = x[n - 1].toInt()
    }
}

/** Decodes the first audio track of any media file to 16 kHz mono PCM16 using MediaCodec. */
object AudioDecoder {
    fun decode(ctx: Context, uri: Uri, onProgress: (Float) -> Unit): ShortArray {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
                if (m != null && m.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) return ShortArray(0)
            val fmt = ex.getTrackFormat(track)
            ex.selectTrack(track)
            val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val rs = Resampler(fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE), 16000)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()
            val sink = ShortSink()
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = c.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val frames = sb.remaining() / ch
                        val mono = ShortArray(frames)
                        for (f in 0 until frames) {
                            var acc = 0
                            for (k in 0 until ch) acc += sb.get().toInt()
                            mono[f] = (acc / ch).toShort()
                        }
                        rs.feed(mono, frames, sink)
                        if (durationUs > 0) onProgress((info.presentationTimeUs.toFloat() / durationUs).coerceIn(0f, 1f))
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    rs.srcRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            return sink.toArray()
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            codec?.release()
            ex.release()
        }
    }
}
