package com.beamer

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import java.util.concurrent.CountDownLatch

class BeamerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread {
            try {
                YoutubeDL.getInstance().init(this)
                FFmpeg.getInstance().init(this)
            } catch (e: Throwable) {
                initError = e.message ?: e.toString()
            } finally {
                ready.countDown()
            }
        }.start()
    }

    companion object {
        val ready = CountDownLatch(1)
        @Volatile var initError: String? = null
    }
}
