package com.beamer

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

enum class Screen { WORKSPACE, EDITOR, SETTINGS }

class BeamerViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)

    var settings by mutableStateOf(store.load())
        private set
    var url by mutableStateOf("")
        private set
    var videoUri by mutableStateOf<Uri?>(null)
        private set
    var videoName by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set
    var progress by mutableStateOf(0f)
        private set
    var status by mutableStateOf("")
        private set
    var method by mutableStateOf("")
        private set
    var screen by mutableStateOf(Screen.WORKSPACE)
        private set
    val blocks = mutableStateListOf<Block>()
    private var job: Job? = null

    fun go(s: Screen) { screen = s }

    fun update(s: AppSettings) {
        settings = s
        store.save(s)
    }

    fun onUrlChange(t: String) {
        url = t
        if (t.isNotBlank()) { videoUri = null; videoName = "" }
    }

    fun setVideo(uri: Uri) {
        videoUri = uri
        url = ""
        videoName = getApplication<Application>().contentResolver
            .query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            } ?: (uri.lastPathSegment ?: "video")
    }

    fun extract() {
        val vu = videoUri
        val src: Source = when {
            url.isNotBlank() -> Source.Url(url.trim())
            vu != null -> Source.Video(vu)
            else -> { status = "Paste a link or pick a video first."; return }
        }
        job?.cancel()
        job = viewModelScope.launch {
            busy = true
            progress = 0f
            status = "Starting…"
            try {
                val r = Pipeline.run(getApplication<Application>(), src, settings) { msg, p ->
                    status = msg
                    progress = p
                }
                blocks.clear()
                blocks.addAll(r.blocks)
                method = r.method
                if (r.blocks.isEmpty()) {
                    status = "No text found. Try another extraction mode in Settings."
                } else {
                    status = ""
                    screen = Screen.EDITOR
                }
            } catch (e: CancellationException) {
                status = "Cancelled"
                throw e
            } catch (e: Throwable) {
                status = "Failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun cancel() { job?.cancel() }

    // ---- editing ----
    private fun idx(id: Long) = blocks.indexOfFirst { it.id == id }

    fun updateText(id: Long, t: String) { val i = idx(id); if (i >= 0) blocks[i] = blocks[i].copy(text = t) }
    fun delete(id: Long) { val i = idx(id); if (i >= 0) blocks.removeAt(i) }
    fun mergeNext(id: Long) {
        val i = idx(id)
        if (i < 0 || i >= blocks.lastIndex) return
        blocks[i] = blocks[i].copy(text = blocks[i].text.trimEnd() + "\n" + blocks[i + 1].text)
        blocks.removeAt(i + 1)
    }
    fun mergePrev(id: Long) { val i = idx(id); if (i > 0) mergeNext(blocks[i - 1].id) }
    fun insertAfter(id: Long?) {
        val i = if (id == null) -1 else idx(id)
        val prev = blocks.getOrNull(i)
        blocks.add(i + 1, Block(Ids.next(), prev?.speaker ?: "SPEAKER 1", ""))
    }

    /** Renames a speaker everywhere. */
    fun renameSpeaker(old: String, new: String) {
        val n = new.trim().removePrefix("[").removeSuffix("]").trim()
        if (n.isEmpty()) return
        for (i in blocks.indices) if (blocks[i].speaker == old) blocks[i] = blocks[i].copy(speaker = n)
    }

    // ---- export ----
    private fun title() = "Beamer transcript"

    fun copy() {
        val app = getApplication<Application>()
        val cm = app.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Beamer", Exporter.toText(blocks.toList(), false, title())))
        toast("Copied")
    }

    fun export(uri: Uri, fmt: String) {
        val app = getApplication<Application>()
        val snap = blocks.toList()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                app.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                    when (fmt) {
                        "pdf" -> Exporter.writePdf(out, title(), snap)
                        "md" -> out.write(Exporter.toText(snap, true, title()).toByteArray())
                        else -> out.write(Exporter.toText(snap, false, title()).toByteArray())
                    }
                }
                toast("Saved")
            } catch (e: Exception) {
                toast("Save failed: ${e.message}")
            }
        }
    }

    private fun toast(msg: String) {
        val app = getApplication<Application>()
        Handler(Looper.getMainLooper()).post { Toast.makeText(app, msg, Toast.LENGTH_SHORT).show() }
    }
}
