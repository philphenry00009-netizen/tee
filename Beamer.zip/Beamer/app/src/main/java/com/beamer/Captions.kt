package com.beamer

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteBuffer

object CaptionParser {
    private val tag = Regex("<[^>]+>")
    private val noise = Regex("(?i)\\[(music|applause|laughter|silence)\\]")

    /** Parses WebVTT or SRT text into clean, de-duplicated lines. */
    fun parse(content: String): List<String> {
        val texts = ArrayList<String>()
        var inCue = false
        for (raw in content.lines()) {
            val line = raw.trim()
            if (line.contains("-->")) { inCue = true; continue }
            if (line.isEmpty()) { inCue = false; continue }
            if (!inCue) continue
            val t = clean(line)
            if (t.isNotEmpty()) texts.add(t)
        }
        return dedupe(texts)
    }

    private fun clean(s: String): String = s
        .replace(tag, "")
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&nbsp;", " ").replace("&#39;", "'").replace("&quot;", "\"")
        .replace(noise, "").replace("\u266A", "")
        .replace(Regex("\\s+"), " ").trim()

    /** Auto-captions repeat the previous line in the next cue; drop those rolling repeats. */
    fun dedupe(lines: List<String>): List<String> {
        val out = ArrayList<String>()
        for (l in lines) {
            val t = l.trim()
            if (t.isEmpty()) continue
            if (out.takeLast(4).contains(t)) continue
            out.add(t)
        }
        return out
    }

    fun toBlocks(lines: List<String>): List<Block> {
        val blocks = ArrayList<Block>()
        val sb = StringBuilder()
        var speaker = 1
        fun flush() {
            val t = sb.toString().trim()
            if (t.isNotEmpty()) blocks.add(Block(Ids.next(), "SPEAKER $speaker", t))
            sb.setLength(0)
        }
        for (l in lines) {
            var t = l
            if (t.startsWith(">>")) {
                if (blocks.isNotEmpty() || sb.isNotEmpty()) {
                    flush()
                    speaker = if (speaker == 1) 2 else 1
                }
                t = t.removePrefix(">>").trim()
            }
            if (t.isEmpty()) continue
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(t)
            if (sb.length > 420 && ".?!".indexOf(t.last()) >= 0) flush()
        }
        flush()
        return blocks
    }
}

/** Reads subtitle tracks muxed into a video container (tx3g / WebVTT / SRT) when present. */
object EmbeddedCaptions {
    fun read(ctx: Context, uri: Uri): List<String> {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            val lines = ArrayList<String>()
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (!(mime.startsWith("text/") || mime == "application/x-subrip")) continue
                ex.selectTrack(i)
                val buf = ByteBuffer.allocate(64 * 1024)
                while (true) {
                    buf.clear()
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) break
                    val bytes = ByteArray(n)
                    buf.position(0)
                    buf.get(bytes, 0, n)
                    val t = decode(mime, bytes)
                    if (t != null) lines.add(t)
                    ex.advance()
                }
                ex.unselectTrack(i)
                if (lines.isNotEmpty()) break
            }
            return lines
        } catch (e: Exception) {
            return emptyList()
        } finally {
            ex.release()
        }
    }

    private fun decode(mime: String, b: ByteArray): String? {
        val text = when (mime) {
            "text/3gpp-tt" ->
                if (b.size >= 2) {
                    val len = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
                    String(b, 2, minOf(len, b.size - 2), Charsets.UTF_8)
                } else ""
            "text/vtt" -> {
                val s = String(b, Charsets.UTF_8)
                val i = s.indexOf("payl")
                if (i >= 0) s.substring(i + 4) else ""
            }
            else -> String(b, Charsets.UTF_8)
        }
        val t = text.replace(Regex("<[^>]+>"), "")
            .replace(Regex("[\\u0000-\\u0008\\u000B-\\u001F]"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return if (t.isEmpty()) null else t
    }
}
