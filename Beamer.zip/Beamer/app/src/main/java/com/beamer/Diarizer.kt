package com.beamer

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class Turn(val startMs: Long, val endMs: Long, val speaker: Int)

/**
 * Lightweight, dependency-free diarization: energy VAD -> windows -> (MFCC + pitch) features
 * -> average-linkage clustering. Swap this object for an ONNX embedding model for higher accuracy.
 */
object Diarizer {
    private const val SR = 16000
    private const val FRAME = 480   // 30 ms
    private const val NFFT = 512
    private const val MELS = 20

    private val hamming = DoubleArray(FRAME) { 0.54 - 0.46 * cos(2 * PI * it / (FRAME - 1)) }
    private val melBank: Array<DoubleArray> = buildMelBank()

    fun run(pcm: ShortArray, speakerCount: Int): List<Turn> {
        val nFrames = pcm.size / FRAME
        if (nFrames < 20) return emptyList()
        val en = DoubleArray(nFrames) { f ->
            var s = 0.0
            val o = f * FRAME
            for (i in 0 until FRAME) { val v = pcm[o + i] / 32768.0; s += v * v }
            sqrt(s / FRAME)
        }
        val sorted = en.sortedArray()
        val floor = sorted[(sorted.size * 0.1).toInt()]
        val thr = maxOf(floor * 3.0, 0.004)
        val speech = BooleanArray(nFrames) { en[it] > thr }

        var i = 0
        while (i < nFrames) {
            if (!speech[i]) {
                var j = i
                while (j < nFrames && !speech[j]) j++
                if (i > 0 && j < nFrames && j - i < 10) for (k in i until j) speech[k] = true
                i = j
            } else i++
        }
        val runs = ArrayList<IntArray>()
        i = 0
        while (i < nFrames) {
            if (speech[i]) {
                var j = i
                while (j < nFrames && speech[j]) j++
                if (j - i >= 8) runs.add(intArrayOf(i, j))
                i = j
            } else i++
        }
        if (runs.isEmpty()) return emptyList()
        var speechFrames = 0
        for (r in runs) speechFrames += r[1] - r[0]
        val win = maxOf(50, speechFrames / 300)
        val wins = ArrayList<IntArray>()
        for (r in runs) {
            var a = r[0]
            while (a < r[1]) {
                var b = minOf(r[1], a + win)
                if (r[1] - b < win / 2) b = r[1]
                wins.add(intArrayOf(a, b))
                a = b
            }
        }
        val feats = ArrayList<DoubleArray>()
        val spans = ArrayList<IntArray>()
        for (w in wins) {
            val f = windowFeature(pcm, w[0], w[1]) ?: continue
            feats.add(f)
            spans.add(w)
        }
        if (feats.isEmpty()) return emptyList()

        val dim = feats[0].size
        for (d in 0 until dim) {
            var m = 0.0
            for (f in feats) m += f[d]
            m /= feats.size
            var v = 0.0
            for (f in feats) v += (f[d] - m) * (f[d] - m)
            val sd = maxOf(sqrt(v / feats.size), 1e-6)
            val wgt = if (d == dim - 1) 2.0 else 1.0
            for (f in feats) f[d] = (f[d] - m) / sd * wgt
        }
        val labels = cluster(feats, speakerCount)
        val turns = ArrayList<Turn>()
        for (x in spans.indices) turns.add(Turn(spans[x][0] * 30L, spans[x][1] * 30L, labels[x]))
        return turns
    }

    private fun windowFeature(pcm: ShortArray, f0: Int, f1: Int): DoubleArray? {
        val melAcc = DoubleArray(MELS)
        var cnt = 0
        val pitches = ArrayList<Double>()
        val re = DoubleArray(NFFT)
        val im = DoubleArray(NFFT)
        var f = f0
        var idx = 0
        while (f < f1) {
            val o = f * FRAME
            for (i in 0 until NFFT) {
                re[i] = if (i < FRAME) pcm[o + i] / 32768.0 * hamming[i] else 0.0
                im[i] = 0.0
            }
            fft(re, im)
            for (m in 0 until MELS) {
                var s = 0.0
                val fb = melBank[m]
                for (k in 0..NFFT / 2) if (fb[k] != 0.0) s += fb[k] * (re[k] * re[k] + im[k] * im[k])
                melAcc[m] += ln(s + 1e-10)
            }
            cnt++
            if (idx % 2 == 0) pitch(pcm, o)?.let { pitches.add(it) }
            idx++
            f += 3
        }
        if (cnt == 0) return null
        val mel = DoubleArray(MELS) { melAcc[it] / cnt }
        val out = DoubleArray(13)
        for (c in 1..12) {
            var s = 0.0
            for (m in 0 until MELS) s += mel[m] * cos(PI * c * (m + 0.5) / MELS)
            out[c - 1] = s
        }
        pitches.sort()
        out[12] = if (pitches.isEmpty()) ln(150.0) else ln(pitches[pitches.size / 2])
        return out
    }

    private fun pitch(pcm: ShortArray, o: Int): Double? {
        var e0 = 0.0
        for (i in 0 until FRAME) { val v = pcm[o + i].toDouble(); e0 += v * v }
        if (e0 < 1.0) return null
        var bestLag = 0
        var best = 0.0
        for (lag in 40..213) {
            var s = 0.0
            for (i in 0 until FRAME - lag) s += pcm[o + i].toDouble() * pcm[o + i + lag].toDouble()
            val r = s / e0
            if (r > best) { best = r; bestLag = lag }
        }
        return if (best > 0.3 && bestLag > 0) SR.toDouble() / bestLag else null
    }

    private fun cluster(f: List<DoubleArray>, forced: Int): IntArray {
        val n = f.size
        if (n == 1 || forced == 1) return IntArray(n)
        val d = Array(n) { a -> DoubleArray(n) { b -> dist(f[a], f[b]) } }
        val active = BooleanArray(n) { true }
        val size = IntArray(n) { 1 }
        val ma = IntArray(n - 1)
        val mb = IntArray(n - 1)
        val md = DoubleArray(n - 1)
        for (step in 0 until n - 1) {
            var bi = -1
            var bj = -1
            var best = Double.MAX_VALUE
            for (a in 0 until n) {
                if (!active[a]) continue
                for (b in a + 1 until n) {
                    if (active[b] && d[a][b] < best) { best = d[a][b]; bi = a; bj = b }
                }
            }
            ma[step] = bi; mb[step] = bj; md[step] = best
            for (m in 0 until n) {
                if (!active[m] || m == bi || m == bj) continue
                val nd = (size[bi] * d[bi][m] + size[bj] * d[bj][m]) / (size[bi] + size[bj])
                d[bi][m] = nd
                d[m][bi] = nd
            }
            size[bi] += size[bj]
            active[bj] = false
        }
        val k = if (forced > 1) minOf(forced, n) else autoK(md, n)
        val parent = IntArray(n) { it }
        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) r = parent[r]
            return r
        }
        for (s in 0 until n - k) {
            val ra = find(ma[s])
            val rb = find(mb[s])
            if (ra != rb) parent[rb] = ra
        }
        val map = HashMap<Int, Int>()
        val out = IntArray(n)
        for (x in 0 until n) {
            val r = find(x)
            out[x] = map.getOrPut(r) { map.size }
        }
        return out
    }

    private fun autoK(md: DoubleArray, n: Int): Int {
        var bestJ = -1
        var bestRatio = 1.0
        for (j in 1 until md.size) {
            val before = n - j
            if (before < 2 || before > 6) continue
            val ratio = md[j] / maxOf(md[j - 1], 1e-9)
            if (ratio > bestRatio) { bestRatio = ratio; bestJ = j }
        }
        return if (bestJ >= 0 && bestRatio >= 1.5) n - bestJ else 1
    }

    private fun dist(a: DoubleArray, b: DoubleArray): Double {
        var s = 0.0
        for (i in a.indices) { val x = a[i] - b[i]; s += x * x }
        return sqrt(s)
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr = cos(ang)
            val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0
                var ci = 0.0
                val half = len / 2
                for (k in 0 until half) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val xr = re[i + k + half] * cr - im[i + k + half] * ci
                    val xi = re[i + k + half] * ci + im[i + k + half] * cr
                    re[i + k] = ur + xr
                    im[i + k] = ui + xi
                    re[i + k + half] = ur - xr
                    im[i + k + half] = ui - xi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun buildMelBank(): Array<DoubleArray> {
        fun hz2mel(h: Double) = 2595.0 * log10(1.0 + h / 700.0)
        fun mel2hz(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)
        val lo = hz2mel(80.0)
        val hi = hz2mel(7600.0)
        val bins = IntArray(MELS + 2) {
            val m = lo + (hi - lo) * it / (MELS + 1)
            ((NFFT + 1) * mel2hz(m) / SR).toInt()
        }
        return Array(MELS) { m ->
            val f = DoubleArray(NFFT / 2 + 1)
            val l = bins[m]
            val c = bins[m + 1]
            val r = bins[m + 2]
            if (c > l) for (k in l until c) f[k] = (k - l).toDouble() / (c - l)
            if (r > c) for (k in c until r) f[k] = (r - k).toDouble() / (r - c)
            f
        }
    }
}
