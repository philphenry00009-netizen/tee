package com.beamer

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.OutputStream

object Exporter {
    /** Consecutive blocks from the same speaker are merged under one header. */
    private fun grouped(blocks: List<Block>): List<Pair<String, List<String>>> {
        val res = ArrayList<Pair<String, MutableList<String>>>()
        for (b in blocks) {
            val t = b.text.trim()
            if (t.isEmpty()) continue
            if (res.isNotEmpty() && res.last().first == b.speaker) res.last().second.add(t)
            else res.add(b.speaker to mutableListOf(t))
        }
        return res
    }

    fun toText(blocks: List<Block>, markdown: Boolean, title: String): String {
        val sb = StringBuilder()
        if (markdown) sb.append("# ").append(title).append("\n\n")
        for ((spk, paras) in grouped(blocks)) {
            sb.append(if (markdown) "**[$spk]**\n\n" else "[$spk]\n")
            sb.append(paras.joinToString("\n\n")).append("\n\n")
        }
        return sb.toString().trimEnd() + "\n"
    }

    fun writePdf(out: OutputStream, title: String, blocks: List<Block>) {
        val doc = PdfDocument()
        val pw = 595
        val ph = 842
        val m = 48f
        val maxW = pw - 2 * m
        val lineH = 16f
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = Color.BLACK }
        val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; typeface = Typeface.DEFAULT_BOLD; color = Color.rgb(40, 70, 170) }
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 18f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK }

        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
        var y = m + 12f

        fun newPage() {
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
            y = m + 12f
        }
        fun drawLine(t: String, p: Paint) {
            if (y > ph - m) newPage()
            page.canvas.drawText(t, m, y, p)
            y += lineH
        }
        fun wrap(text: String, p: Paint): List<String> {
            val lines = ArrayList<String>()
            for (raw in text.split('\n')) {
                var cur = ""
                for (w in raw.split(' ')) {
                    if (w.isEmpty()) continue
                    val t = if (cur.isEmpty()) w else "$cur $w"
                    if (p.measureText(t) <= maxW) cur = t
                    else {
                        if (cur.isNotEmpty()) lines.add(cur)
                        cur = w
                    }
                }
                if (cur.isNotEmpty()) lines.add(cur)
            }
            return lines
        }

        page.canvas.drawText(title, m, y, big)
        y += 30f
        for ((spk, paras) in grouped(blocks)) {
            drawLine("[$spk]", head)
            y += 2f
            for (para in paras) {
                for (ln in wrap(para, body)) drawLine(ln, body)
                y += 6f
            }
            y += 6f
        }
        doc.finishPage(page)
        doc.writeTo(out)
        doc.close()
    }
}
