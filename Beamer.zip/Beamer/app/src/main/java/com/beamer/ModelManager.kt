package com.beamer

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Whisper ggml models are downloaded once, then everything runs offline. */
object ModelManager {
    fun file(ctx: Context, name: String): File {
        val dir = File(ctx.filesDir, "models")
        dir.mkdirs()
        return File(dir, "ggml-$name.bin")
    }

    fun isReady(ctx: Context, name: String): Boolean {
        val f = file(ctx, name)
        return f.exists() && f.length() > 10_000_000L
    }

    fun download(ctx: Context, name: String, onProgress: (Float) -> Unit): File {
        val dest = file(ctx, name)
        if (isReady(ctx, name)) return dest
        val tmp = File(dest.path + ".part")
        val conn = URL("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-$name.bin")
            .openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        try {
            conn.connect()
            if (conn.responseCode !in 200..299) error("Model download failed: HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress(done.toFloat() / total)
                    }
                }
            }
            if (!tmp.renameTo(dest)) error("Could not save model file")
        } finally {
            conn.disconnect()
        }
        return dest
    }
}
