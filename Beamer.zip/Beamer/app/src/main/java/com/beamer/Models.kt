package com.beamer

import android.net.Uri
import java.util.concurrent.atomic.AtomicLong

enum class ExtractionMode(val label: String) {
    AUTO("Auto Hybrid"), CHAT_OCR("Chat OCR Only"), AUDIO("Audio + Diarization Only")
}

data class Block(val id: Long, val speaker: String, val text: String, val timeMs: Long = 0L)

data class AppSettings(
    val mode: ExtractionMode = ExtractionMode.AUTO,
    val sampleIntervalMs: Long = 1000L,
    val cropTopPct: Float = 0.07f,
    val cropBottomPct: Float = 0.12f,
    val splitX: Float = 0.18f,
    val userOnRight: Boolean = true,
    val similarity: Float = 0.82f,
    val whisperModel: String = "tiny",
    val speakerCount: Int = 0,
    val exportFormat: String = "md",
    val speakerPresets: String = "USER, AI, HOST, GUEST",
)

sealed class Source {
    data class Url(val url: String) : Source()
    data class Video(val uri: Uri) : Source()
}

class ExtractionResult(val blocks: List<Block>, val method: String)

data class OcrLine(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)
data class FrameResult(val timeMs: Long, val width: Int, val height: Int, val lines: List<OcrLine>)

object Ids {
    private val n = AtomicLong()
    fun next() = n.incrementAndGet()
}
