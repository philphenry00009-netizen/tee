package com.beamer

import kotlin.math.max
import kotlin.math.min

/** Fuzzy text similarity helpers (normalised Levenshtein, prefix/suffix aware). */
object Sim {
    private val nonWord = Regex("[^\\p{L}\\p{N}]+")

    fun norm(t: String) = t.lowercase().replace(nonWord, " ").trim()

    fun similar(a: String, b: String, th: Double): Boolean {
        if (a == b) return true
        val s = if (a.length <= b.length) a else b
        val l = if (a.length <= b.length) b else a
        if (s.length < 12) return false
        val n = min(s.length, 300)
        return ratio(s.take(n), l.take(n)) >= th || ratio(s.takeLast(n), l.takeLast(n)) >= th
    }

    private fun ratio(a: String, b: String): Double {
        val m = max(a.length, b.length)
        if (m == 0) return 1.0
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return 1.0 - prev[b.length].toDouble() / m
    }
}

data class OLine(val text: String, val speaker: String, val newPara: Boolean)

object OcrText {
    private val junk = listOf(
        Regex("""\d{1,2}[:.]\d{2}(\s?[AaPp]\.?[Mm]\.?)?"""),
        Regex("""\d{1,3}\s?%"""),
        Regex("""(?i)(lte|5g|4g|3g|wifi|wi-fi|volte)"""),
        Regex("""(?i)(today|yesterday|delivered|seen|typing\.*|message|send|copy|share|regenerate|edited|you|chatgpt|claude|gemini|grok|ai)"""),
        Regex("""(?i)(type a message.*|ask anything.*|message claude.*|reply to claude.*|message chatgpt.*)"""),
        Regex("""[^\p{L}\p{N}]{1,3}"""),
    )
    private val bullet = Regex("""^([•·●▪\-*]|\d{1,2}[.)])\s""")

    private fun tidy(t: String) = t.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
    private fun isJunk(t: String) = t.length < 2 || junk.any { it.matches(t.trim()) }

    /** One OCR frame -> cleaned, speaker-tagged lines. Lines touching the crop zones are dropped. */
    fun frameLines(f: FrameResult, s: AppSettings): List<OLine> {
        val top = f.height * s.cropTopPct
        val bottom = f.height * (1f - s.cropBottomPct)
        val lines = f.lines
            .filter { it.top >= top && it.bottom <= bottom }
            .map { it.copy(text = tidy(it.text)) }
            .filter { !isJunk(it.text) }
            .sortedBy { it.top }
        val out = ArrayList<OLine>()
        var prev: OcrLine? = null
        var prevSp = ""
        for (l in lines) {
            val rightSide = l.left.toFloat() / f.width > s.splitX
            val sp = if (rightSide == s.userOnRight) "USER" else "AI"
            val p = prev
            val newPara = p == null || sp != prevSp || (l.top - p.bottom) > 0.7f * (p.bottom - p.top)
            out.add(OLine(l.text, sp, newPara))
            prev = l
            prevSp = sp
        }
        return out
    }

    fun toBlocks(lines: List<OLine>): List<Block> {
        val out = ArrayList<Block>()
        val sb = StringBuilder()
        var sp = ""
        fun flush() {
            val t = sb.toString().trim()
            if (t.isNotEmpty()) out.add(Block(Ids.next(), sp, t))
            sb.setLength(0)
        }
        for (l in lines) {
            if (l.speaker != sp || l.newPara) {
                flush()
                sp = l.speaker
            } else {
                sb.append(if (bullet.containsMatchIn(l.text)) '\n' else ' ')
            }
            sb.append(l.text)
        }
        flush()
        return out
    }
}

/**
 * Overlap-stitching: each new frame is aligned against the tail of the running script
 * (longest run of fuzzy-equal lines). Only lines that are NOT already present are added,
 * in the right place (below for scroll-down, above for scroll-up). Clipped lines are
 * upgraded to the longer, fuller version when it appears.
 */
class Stitcher(private val th: Double) {
    val lines = ArrayList<OLine>()
    private val norms = ArrayList<String>()

    private fun same(a: String, b: String) = a.isNotEmpty() && b.isNotEmpty() && Sim.similar(a, b, th)

    private fun push(at: Int, l: OLine) {
        lines.add(at, l)
        norms.add(at, Sim.norm(l.text))
    }

    fun add(frame: List<OLine>) {
        if (frame.isEmpty()) return
        val fn = frame.map { Sim.norm(it.text) }
        if (lines.isEmpty()) {
            for (l in frame) push(lines.size, l)
            return
        }
        var bestRun = 0
        var bestG = -1
        var bestJ = 0
        val from = max(0, lines.size - 250)
        for (g in from until lines.size) {
            for (j in frame.indices) {
                var r = 0
                while (g + r < lines.size && j + r < frame.size && same(norms[g + r], fn[j + r])) r++
                if (r > bestRun && (r >= 2 || fn[j].length >= 10)) {
                    bestRun = r; bestG = g; bestJ = j
                }
            }
        }
        if (bestRun == 0) {
            for (l in frame) push(lines.size, l)
            return
        }
        for (k in 0 until bestJ) push(bestG + k, frame[k])
        var p = bestG + bestJ
        for (j in bestJ until frame.size) {
            var m = -1
            for (q in p until min(lines.size, p + 4)) {
                if (same(norms[q], fn[j])) { m = q; break }
            }
            if (m >= 0) {
                if (fn[j].length > norms[m].length) {
                    lines[m] = lines[m].copy(text = frame[j].text)
                    norms[m] = fn[j]
                }
                p = m + 1
            } else {
                push(p, frame[j])
                p++
            }
        }
    }
}
