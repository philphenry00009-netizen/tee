package com.beamer

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.withContext
import java.io.File

/** Waterfall: captions -> OCR -> offline audio (whisper + diarization). */
object Pipeline {
    suspend fun run(ctx: Context, src: Source, s: AppSettings, status: (String, Float) -> Unit): ExtractionResult =
        withContext(Dispatchers.Default) {
            when (src) {
                is Source.Url -> runUrl(ctx, src.url, s, status)
                is Source.Video -> runVideo(ctx, src.uri, s, status)
            }
        }

    private fun runUrl(ctx: Context, url: String, s: AppSettings, status: (String, Float) -> Unit): ExtractionResult {
        val dir = File(ctx.cacheDir, "dl")
        dir.deleteRecursively()
        dir.mkdirs()
        if (s.mode != ExtractionMode.AUDIO) {
            status("Checking for captions…", 0.05f)
            val cap = UrlFetcher.captions(url, dir)
            if (cap != null) {
                val lines = CaptionParser.parse(cap.readText())
                if (lines.isNotEmpty()) return ExtractionResult(CaptionParser.toBlocks(lines), "Captions (no audio downloaded)")
            }
        }
        status("No captions found. Downloading audio only…", 0.12f)
        val audio = UrlFetcher.audio(url, dir)
        return transcribe(ctx, Uri.fromFile(audio), s, status)
    }

    private suspend fun runVideo(ctx: Context, uri: Uri, s: AppSettings, status: (String, Float) -> Unit): ExtractionResult {
        if (s.mode == ExtractionMode.AUTO) {
            status("Looking for embedded captions…", 0.03f)
            val emb = EmbeddedCaptions.read(ctx, uri)
            val lines = CaptionParser.dedupe(emb)
            if (lines.isNotEmpty()) return ExtractionResult(CaptionParser.toBlocks(lines), "Embedded captions")
        }
        if (s.mode != ExtractionMode.AUDIO) {
            status("Reading on-screen text (OCR)…", 0.05f)
            val blocks = ocrBlocks(ctx, uri, s) { p -> status("Reading on-screen text (OCR)…", 0.05f + 0.8f * p) }
            var total = 0
            for (b in blocks) total += b.text.length
            if ((blocks.isNotEmpty() && total >= 80) || s.mode == ExtractionMode.CHAT_OCR) {
                return ExtractionResult(blocks, "On-screen text (OCR)")
            }
        }
        status("No on-screen text. Switching to audio…", 0.1f)
        return transcribe(ctx, uri, s, status)
    }

    private suspend fun ocrBlocks(ctx: Context, uri: Uri, s: AppSettings, onProgress: (Float) -> Unit): List<Block> {
        val stitcher = Stitcher(s.similarity.toDouble())
        FrameExtractor(ctx, uri).use { ex ->
            OcrEngine().use { ocr ->
                ex.frames(s.sampleIntervalMs, 1.0).collect { f ->
                    try {
                        val fr = ocr.recognize(f.bitmap, f.timeMs)
                        stitcher.add(OcrText.frameLines(fr, s))
                    } finally {
                        f.bitmap.recycle()
                    }
                    onProgress(f.progress)
                }
            }
        }
        return OcrText.toBlocks(stitcher.lines)
    }

    private fun transcribe(ctx: Context, uri: Uri, s: AppSettings, status: (String, Float) -> Unit): ExtractionResult {
        status("Decoding audio…", 0.1f)
        val pcm = AudioDecoder.decode(ctx, uri) { p -> status("Decoding audio…", 0.1f + 0.15f * p) }
        if (pcm.size < 16000) error("No audio track found.")
        if (!ModelManager.isReady(ctx, s.whisperModel)) {
            status("Downloading Whisper ${s.whisperModel} model (one time)…", 0.25f)
            ModelManager.download(ctx, s.whisperModel) { p -> status("Downloading Whisper ${s.whisperModel} model (one time)…", 0.25f + 0.1f * p) }
        }
        val segs = Transcriber.run(ctx, pcm, s.whisperModel) { p -> status("Transcribing offline…", 0.35f + 0.55f * p) }
        status("Separating speakers…", 0.92f)
        val turns = Diarizer.run(pcm, s.speakerCount)
        return ExtractionResult(segsToBlocks(segs, turns), "Whisper ${s.whisperModel} + diarization")
    }

    private fun speakerFor(sg: Seg, turns: List<Turn>): Int {
        if (turns.isEmpty()) return 0
        var best = -1
        var bestOv = 0L
        for (t in turns) {
            val ov = minOf(sg.endMs, t.endMs) - maxOf(sg.startMs, t.startMs)
            if (ov > bestOv) { bestOv = ov; best = t.speaker }
        }
        if (best >= 0) return best
        val mid = (sg.startMs + sg.endMs) / 2
        var nearest = turns[0]
        var nd = Long.MAX_VALUE
        for (t in turns) {
            val d = minOf(Math.abs(t.startMs - mid), Math.abs(t.endMs - mid))
            if (d < nd) { nd = d; nearest = t }
        }
        return nearest.speaker
    }

    private fun segsToBlocks(segs: List<Seg>, turns: List<Turn>): List<Block> {
        val out = ArrayList<Block>()
        val sb = StringBuilder()
        var cur = -1
        var t0 = 0L
        fun flush() {
            val t = sb.toString().trim()
            if (t.isNotEmpty()) out.add(Block(Ids.next(), "SPEAKER ${cur + 1}", t, t0))
            sb.setLength(0)
        }
        for (sg in segs) {
            val spk = speakerFor(sg, turns)
            if (spk != cur || (sb.length > 500 && ".?!".indexOf(sb.last()) >= 0)) {
                flush()
                cur = spk
                t0 = sg.startMs
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(sg.text)
        }
        flush()
        return out
    }
}
