package com.beamer

import android.content.Context

class SettingsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("beamer", Context.MODE_PRIVATE)

    fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            mode = try { ExtractionMode.valueOf(sp.getString("mode", d.mode.name) ?: d.mode.name) } catch (e: Exception) { d.mode },
            sampleIntervalMs = sp.getLong("interval", d.sampleIntervalMs),
            cropTopPct = sp.getFloat("cropTop", d.cropTopPct),
            cropBottomPct = sp.getFloat("cropBottom", d.cropBottomPct),
            splitX = sp.getFloat("splitX", d.splitX),
            userOnRight = sp.getBoolean("userRight", d.userOnRight),
            similarity = sp.getFloat("similarity", d.similarity),
            whisperModel = sp.getString("model", d.whisperModel) ?: d.whisperModel,
            speakerCount = sp.getInt("speakers", d.speakerCount),
            exportFormat = sp.getString("export", d.exportFormat) ?: d.exportFormat,
            speakerPresets = sp.getString("presets", d.speakerPresets) ?: d.speakerPresets,
        )
    }

    fun save(s: AppSettings) {
        sp.edit()
            .putString("mode", s.mode.name)
            .putLong("interval", s.sampleIntervalMs)
            .putFloat("cropTop", s.cropTopPct)
            .putFloat("cropBottom", s.cropBottomPct)
            .putFloat("splitX", s.splitX)
            .putBoolean("userRight", s.userOnRight)
            .putFloat("similarity", s.similarity)
            .putString("model", s.whisperModel)
            .putInt("speakers", s.speakerCount)
            .putString("export", s.exportFormat)
            .putString("presets", s.speakerPresets)
            .apply()
    }
}
