package com.beamer

import android.content.Context
import kotlin.math.abs

data class Seg(val startMs: Long, val endMs: Long, val text: String)

/** Offline whisper.cpp transcription in ~5 minute chunks cut at the quietest point. */
object Transcriber {
    fun run(ctx: Context, pcm: ShortArray, modelName: String, onProgress: (Float) -> Unit): List<Seg> {
        val model = ModelManager.file(ctx, modelName)
        val handle = WhisperNative.nativeInit(model.absolutePath)
        if (handle == 0L) error("Could not load the Whisper model.")
        try {
            val out = ArrayList<Seg>()
            val chunk = 16000 * 300
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
            var start = 0
            while (start < pcm.size) {
                var end = minOf(pcm.size, start + chunk)
                if (end < pcm.size) end = quietestPoint(pcm, end - 160000, minOf(pcm.size, end + 160000))
                val from = start
                val len = end - from
                val f = FloatArray(len) { pcm[from + it] / 32768f }
                val raw = String(WhisperNative.nativeTranscribe(handle, f, threads, "auto"), Charsets.UTF_8)
                val offMs = from * 1000L / 16000
                for (line in raw.lines()) {
                    val p = line.split('\t', limit = 3)
                    if (p.size < 3) continue
                    val t0 = p[0].toLongOrNull() ?: continue
                    val t1 = p[1].toLongOrNull() ?: continue
                    val text = p[2].trim()
                    if (text.isEmpty() || isNoise(text)) continue
                    out.add(Seg(offMs + t0 * 10, offMs + t1 * 10, text))
                }
                start = end
                onProgress(start.toFloat() / pcm.size)
            }
            return out
        } finally {
            WhisperNative.nativeFree(handle)
        }
    }

    private fun isNoise(t: String): Boolean {
        val s = t.trim()
        return s.length < 40 && ((s.startsWith("[") && s.endsWith("]")) || (s.startsWith("(") && s.endsWith(")")))
    }

    private fun quietestPoint(p: ShortArray, a: Int, b: Int): Int {
        var bestPos = (a + b) / 2
        var best = Long.MAX_VALUE
        var pos = a
        while (pos + 1600 <= b) {
            var e = 0L
            for (i in pos until pos + 1600) e += abs(p[i].toInt())
            if (e < best) { best = e; bestPos = pos + 800 }
            pos += 800
        }
        return bestPos
    }
}
