package com.beamer

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Accent = Color(0xFF8AA4FF)
val Ink = Color(0xFFEAF0FF)
val Muted = Color(0xFFA6B0CC)

@Composable
fun BeamerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = Color(0xFF0B1020),
            background = Color(0xFF0B0F1A), surface = Color(0xFF121826),
            onSurface = Ink, onBackground = Ink, secondary = Color(0xFFB388FF)
        ),
        content = content
    )
}

/** Dark gradient + soft blurred orbs (blur is applied on Android 12+, ignored below). */
@Composable
fun Backdrop(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalContentColor provides Ink) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF070A12), Color(0xFF0E1424), Color(0xFF171B38)))
            )
        ) {
            Box(Modifier.size(280.dp).offset(x = (-90).dp, y = (-60).dp).blur(100.dp).background(Color(0x663B5BFF), CircleShape))
            Box(Modifier.size(300.dp).align(Alignment.BottomEnd).offset(x = 90.dp, y = 80.dp).blur(110.dp).background(Color(0x55A855FF), CircleShape))
            content()
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .clip(shape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Chip(text: String, selected: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = if (selected) Color.White else Muted,
        fontSize = 13.sp,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.30f) else Color.White.copy(alpha = 0.06f))
            .border(1.dp, if (selected) Accent else Color.White.copy(alpha = 0.14f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val colors = if (enabled) listOf(Color(0xFF5B7CFF), Color(0xFF9B6BFF)) else listOf(Color(0xFF2A3350), Color(0xFF2A3350))
    Box(
        modifier.clip(shape).background(Brush.horizontalGradient(colors))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.clip(shape).background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.18f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Ink) }
}

@Composable
fun App(vm: BeamerViewModel) {
    BackHandler(enabled = vm.screen != Screen.WORKSPACE) { vm.go(Screen.WORKSPACE) }
    when (vm.screen) {
        Screen.WORKSPACE -> WorkspaceScreen(vm)
        Screen.EDITOR -> EditorScreen(vm)
        Screen.SETTINGS -> SettingsScreen(vm)
    }
}

@Composable
fun WorkspaceScreen(vm: BeamerViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setVideo(uri)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF261C5A), Color(0xFF4A2FD0)))),
                contentAlignment = Alignment.Center
            ) { Text("T", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Beamer", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Video to clean script", color = Muted, fontSize = 12.sp)
            }
            Chip("Settings") { vm.go(Screen.SETTINGS) }
        }

        Glass(Modifier.fillMaxWidth()) {
            Text("Video link", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = vm.url,
                onValueChange = { vm.onUrlChange(it) },
                placeholder = { Text("YouTube, TikTok, Instagram, X…") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Text("or a file on this phone", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            GhostButton(if (vm.videoUri == null) "Pick a video file" else "Change video", Modifier.fillMaxWidth()) {
                picker.launch(arrayOf("video/*", "audio/*"))
            }
            if (vm.videoName.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(vm.videoName, color = Muted, fontSize = 13.sp, maxLines = 1)
            }
        }

        PrimaryButton(
            "Extract", Modifier.fillMaxWidth(),
            enabled = !vm.busy && (vm.url.isNotBlank() || vm.videoUri != null)
        ) { vm.extract() }

        if (vm.busy || vm.status.isNotEmpty()) {
            Glass(Modifier.fillMaxWidth()) {
                Text(vm.status)
                if (vm.busy) {
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    GhostButton("Cancel") { vm.cancel() }
                }
            }
        }

        Glass(Modifier.fillMaxWidth()) {
            Text("Mode: ${vm.settings.mode.label}", color = Muted, fontSize = 13.sp)
            Text("Whisper model: ${vm.settings.whisperModel}", color = Muted, fontSize = 13.sp)
        }

        if (vm.blocks.isNotEmpty() && !vm.busy) {
            GhostButton("Open last transcript (${vm.blocks.size} blocks)", Modifier.fillMaxWidth()) { vm.go(Screen.EDITOR) }
        }
    }
}

@Composable
fun EditorScreen(vm: BeamerViewModel) {
    var renaming by remember { mutableStateOf<String?>(null) }
    val saveTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { u ->
        if (u != null) vm.export(u, "txt")
    }
    val saveMd = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { u ->
        if (u != null) vm.export(u, "md")
    }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { u ->
        if (u != null) vm.export(u, "pdf")
    }
    val fmt = vm.settings.exportFormat

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Chip("‹ Back") { vm.go(Screen.WORKSPACE) }
            Spacer(Modifier.weight(1f))
            Text(vm.method, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(vm.blocks, key = { it.id }) { b -> BlockCard(vm, b) { renaming = b.speaker } }
            item { GhostButton("+ Add block", Modifier.fillMaxWidth()) { vm.insertAfter(vm.blocks.lastOrNull()?.id) } }
        }
        Spacer(Modifier.height(8.dp))
        Glass(Modifier.fillMaxWidth()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Copy") { vm.copy() }
                Chip(".txt", fmt == "txt") { saveTxt.launch("beamer-transcript.txt") }
                Chip(".md", fmt == "md") { saveMd.launch("beamer-transcript.md") }
                Chip(".pdf", fmt == "pdf") { savePdf.launch("beamer-transcript.pdf") }
            }
        }
    }

    val old = renaming
    if (old != null) {
        RenameDialog(old, vm.settings.speakerPresets, { renaming = null }) { n ->
            vm.renameSpeaker(old, n)
            renaming = null
        }
    }
}

@Composable
fun BlockCard(vm: BeamerViewModel, b: Block, onRename: () -> Unit) {
    Glass(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Chip("[${b.speaker}]", true, onRename)
            if (b.timeMs > 0) {
                Spacer(Modifier.width(8.dp))
                Text("${b.timeMs / 60000}:${"%02d".format((b.timeMs / 1000) % 60)}", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = b.text,
            onValueChange = { vm.updateText(b.id, it) },
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { vm.mergePrev(b.id) }) { Text("↑Merge") }
            TextButton(onClick = { vm.mergeNext(b.id) }) { Text("↓Merge") }
            TextButton(onClick = { vm.insertAfter(b.id) }) { Text("+Add") }
            TextButton(onClick = { vm.delete(b.id) }) { Text("Delete") }
        }
    }
}

@Composable
fun RenameDialog(old: String, presets: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(old) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename speaker") },
        text = {
            Column {
                Text("Renames every [$old] block.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets.split(',').map { it.trim() }.filter { it.isNotEmpty() }.forEach { p ->
                        Chip(p, text == p) { text = p }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text("Rename") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label, fontSize = 13.sp, color = Muted)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun SettingsScreen(vm: BeamerViewModel) {
    val s = vm.settings
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Chip("‹ Back") { vm.go(Screen.WORKSPACE) }
            Spacer(Modifier.width(12.dp))
            Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Glass(Modifier.fillMaxWidth()) {
            Text("Extraction mode", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (m in ExtractionMode.values()) Chip(m.label, s.mode == m) { vm.update(s.copy(mode = m)) }
            }
        }

        Glass(Modifier.fillMaxWidth()) {
            Text("Chat OCR", fontWeight = FontWeight.SemiBold)
            SliderRow("Sample every ${"%.1f".format(s.sampleIntervalMs / 1000f)} s", s.sampleIntervalMs.toFloat(), 500f..3000f) {
                vm.update(s.copy(sampleIntervalMs = it.toLong()))
            }
            SliderRow("Crop top ${(s.cropTopPct * 100).toInt()}%", s.cropTopPct, 0f..0.25f) { vm.update(s.copy(cropTopPct = it)) }
            SliderRow("Crop bottom ${(s.cropBottomPct * 100).toInt()}%", s.cropBottomPct, 0f..0.4f) { vm.update(s.copy(cropBottomPct = it)) }
            SliderRow("USER/AI split at ${(s.splitX * 100).toInt()}% of width", s.splitX, 0.05f..0.4f) { vm.update(s.copy(splitX = it)) }
            SliderRow("Duplicate similarity ${(s.similarity * 100).toInt()}%", s.similarity, 0.6f..0.95f) { vm.update(s.copy(similarity = it)) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = s.userOnRight, onCheckedChange = { vm.update(s.copy(userOnRight = it)) })
                Spacer(Modifier.width(10.dp))
                Text("User bubbles are on the right")
            }
        }

        Glass(Modifier.fillMaxWidth()) {
            Text("Whisper model", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (m in listOf("tiny", "base")) Chip(m, s.whisperModel == m) { vm.update(s.copy(whisperModel = m)) }
            }
            Spacer(Modifier.height(6.dp))
            val ready = ModelManager.isReady(ctx, s.whisperModel)
            Text(
                if (ready) "Downloaded. Works fully offline."
                else "Downloads once on first use (tiny ~75 MB, base ~142 MB).",
                color = Muted, fontSize = 12.sp
            )
        }

        Glass(Modifier.fillMaxWidth()) {
            Text("Speakers (audio mode)", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Auto", s.speakerCount == 0) { vm.update(s.copy(speakerCount = 0)) }
                for (n in 1..4) Chip("$n", s.speakerCount == n) { vm.update(s.copy(speakerCount = n)) }
            }
            Spacer(Modifier.height(6.dp))
            Text("If Auto guesses wrong, set the exact number of voices.", color = Muted, fontSize = 12.sp)
        }

        Glass(Modifier.fillMaxWidth()) {
            Text("Export", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (f in listOf("md", "txt", "pdf")) Chip(".$f", s.exportFormat == f) { vm.update(s.copy(exportFormat = f)) }
            }
            Spacer(Modifier.height(12.dp))
            Text("Speaker label presets", color = Muted, fontSize = 13.sp)
            OutlinedTextField(
                value = s.speakerPresets,
                onValueChange = { vm.update(s.copy(speakerPresets = it)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
