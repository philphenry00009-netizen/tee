package com.beamer

import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.concurrent.TimeUnit

/** yt-dlp wrapper: captions first (tiny download), otherwise audio only. */
object UrlFetcher {
    private fun ensureReady() {
        BeamerApp.ready.await(180, TimeUnit.SECONDS)
        val err = BeamerApp.initError
        if (err != null) error("yt-dlp failed to start: $err")
    }

    fun captions(url: String, dir: File): File? {
        ensureReady()
        val req = YoutubeDLRequest(url)
        req.addOption("--skip-download")
        req.addOption("--no-playlist")
        req.addOption("--write-subs")
        req.addOption("--write-auto-subs")
        req.addOption("--sub-langs", "en.*,.*-orig,-live_chat")
        req.addOption("--sub-format", "vtt/srt/best")
        req.addOption("-o", File(dir, "%(id)s.%(ext)s").absolutePath)
        YoutubeDL.getInstance().execute(req)
        return dir.listFiles()
            ?.filter { it.extension == "vtt" || it.extension == "srt" }
            ?.sortedBy { it.name }
            ?.firstOrNull()
    }

    fun audio(url: String, dir: File): File {
        ensureReady()
        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        req.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
        req.addOption("-o", File(dir, "audio_%(id)s.%(ext)s").absolutePath)
        YoutubeDL.getInstance().execute(req)
        return dir.listFiles()
            ?.filter { it.name.startsWith("audio_") && !it.name.endsWith(".part") }
            ?.maxByOrNull { it.length() }
            ?: error("Audio download failed.")
    }
}
