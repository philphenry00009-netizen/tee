package com.beamer

object WhisperNative {
    init { System.loadLibrary("beamer_whisper") }
    external fun nativeInit(path: String): Long
    external fun nativeFree(ctx: Long)
    external fun nativeTranscribe(ctx: Long, audio: FloatArray, threads: Int, lang: String): ByteArray
}
